<?php
/**
 * Plugin Name: WMRN Personnel Authority
 * Description: Personnel authority records on the existing People taxonomy, with the WMRN Personnel Directory and archive-integrated profiles.
 * Version: 1.0.1
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Author: WMRN Radio History Archive
 * Text Domain: wmrn-personnel-authority
 * License: GPL-2.0-or-later
 */
defined( 'ABSPATH' ) || exit;
define( 'WMRN_PERSONNEL_VERSION', '1.0.1' );
define( 'WMRN_PERSONNEL_DIR', plugin_dir_path( __FILE__ ) );
define( 'WMRN_PERSONNEL_URL', plugin_dir_url( __FILE__ ) );
require_once WMRN_PERSONNEL_DIR . 'includes/class-authority.php';
require_once WMRN_PERSONNEL_DIR . 'includes/class-admin.php';
require_once WMRN_PERSONNEL_DIR . 'includes/template-functions.php';
require_once WMRN_PERSONNEL_DIR . 'includes/class-integration.php';
add_action( 'init', [ 'WMRN_Personnel_Authority', 'register' ], 40 );
WMRN_Personnel_Admin::boot();
WMRN_Personnel_Integration::boot();
register_activation_hook( __FILE__, [ 'WMRN_Personnel_Integration', 'activate' ] );
register_deactivation_hook( __FILE__, [ 'WMRN_Personnel_Integration', 'deactivate' ] );
