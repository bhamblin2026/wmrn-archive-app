<?php
defined( 'ABSPATH' ) || exit;

get_header();

$filters = wmrn_personnel_filters();
$result  = wmrn_personnel_directory_records( $filters );
$records = $result['records'];
$stats   = $result['stats'];

$stations      = WMRN_Personnel_Authority::stations();
$roles         = WMRN_Personnel_Authority::roles();
$relationships = WMRN_Personnel_Authority::relationships();
$verification  = WMRN_Personnel_Authority::verification();

$hero_bg = function_exists( 'wmrn_get' ) && function_exists( 'wmrn_asset' )
    ? wmrn_get( 'wmrn_people_hero_image', wmrn_asset( 'images/hero-people.jpg' ) )
    : '';

$tab_args = [
    'people_search' => $filters['search'],
    'station'       => $filters['station'],
    'role'          => $filters['role'],
    'era'           => $filters['era'],
    'year'          => $filters['year'],
    'relationship'  => $filters['relationship'],
    'verification'  => $filters['verification'],
    'employer'      => $filters['employer'],
    'department'    => $filters['department'],
];
?>
<section class="page-hero wmrn-personnel-hero">
    <?php if ( $hero_bg ) : ?>
        <img src="<?php echo esc_url( $hero_bg ); ?>" class="page-hero-bg" alt="" aria-hidden="true">
    <?php endif; ?>
    <div class="page-hero-overlay"></div>
    <div class="page-hero-content">
        <p class="hero-eyebrow"><?php esc_html_e( 'Historical Personnel Authority', 'wmrn-personnel-authority' ); ?></p>
        <h1 class="page-hero-title"><?php esc_html_e( 'WMRN Studios Personnel Directory', 'wmrn-personnel-authority' ); ?></h1>
        <p class="page-hero-subtitle"><?php esc_html_e( 'The people behind WMRN-AM 1490, WMRN-FM 106.9, WDIF 94.3, Majic 95.9, and the shared Marion radio operation based at the WMRN studios.', 'wmrn-personnel-authority' ); ?></p>
    </div>
</section>

<section class="wmrn-personnel-directory">
    <div class="wmrn-container">
        <div class="wmrn-personnel-intro">
            <div class="wmrn-personnel-intro-copy">
                <p><strong><?php esc_html_e( 'A directory of the people who made the WMRN studios work.', 'wmrn-personnel-authority' ); ?></strong></p>
                <p><?php esc_html_e( 'Personnel records can document several stations, changing jobs, overlapping assignments, ownership eras, and surviving archive materials without creating duplicate people.', 'wmrn-personnel-authority' ); ?></p>
            </div>
            <aside class="wmrn-personnel-scope" aria-label="<?php esc_attr_e( 'Directory scope', 'wmrn-personnel-authority' ); ?>">
                <strong><?php esc_html_e( 'Directory scope', 'wmrn-personnel-authority' ); ?></strong>
                <p><?php esc_html_e( 'WMRN remains the archive’s center of gravity. Sister-station and shared-cluster personnel are included when their work formed part of the co-owned Marion operation run from the WMRN studios.', 'wmrn-personnel-authority' ); ?></p>
            </aside>
        </div>

        <div class="wmrn-personnel-stats" aria-label="<?php esc_attr_e( 'Directory statistics', 'wmrn-personnel-authority' ); ?>">
            <div class="wmrn-personnel-stat">
                <strong><?php echo esc_html( number_format_i18n( $stats['personnel'] ) ); ?></strong>
                <span><?php esc_html_e( 'personnel records', 'wmrn-personnel-authority' ); ?></span>
            </div>
            <div class="wmrn-personnel-stat">
                <strong><?php echo esc_html( number_format_i18n( $stats['stations'] ) ); ?></strong>
                <span><?php esc_html_e( 'stations represented', 'wmrn-personnel-authority' ); ?></span>
            </div>
            <div class="wmrn-personnel-stat">
                <strong><?php echo esc_html( number_format_i18n( $stats['linked_accessions'] ) ); ?></strong>
                <span><?php esc_html_e( 'linked accessions', 'wmrn-personnel-authority' ); ?></span>
            </div>
            <div class="wmrn-personnel-stat">
                <strong><?php echo esc_html( number_format_i18n( $stats['archive_people'] ) ); ?></strong>
                <span><?php esc_html_e( 'archive-linked people', 'wmrn-personnel-authority' ); ?></span>
            </div>
        </div>

        <nav class="wmrn-personnel-tabs" aria-label="<?php esc_attr_e( 'Personnel directory views', 'wmrn-personnel-authority' ); ?>">
            <?php
            $tabs = [
                'personnel' => __( 'WMRN Personnel', 'wmrn-personnel-authority' ),
                'archive'   => __( 'People in the Archive', 'wmrn-personnel-authority' ),
                'combined'  => __( 'Combined View', 'wmrn-personnel-authority' ),
            ];
            foreach ( $tabs as $slug => $label ) :
                $url = wmrn_personnel_directory_url( array_merge( $tab_args, [ 'directory_view' => $slug ] ) );
                ?>
                <a class="wmrn-personnel-tab" href="<?php echo esc_url( $url ); ?>" <?php echo $filters['directory_view'] === $slug ? 'aria-current="page"' : ''; ?>>
                    <?php echo esc_html( $label ); ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <form class="wmrn-personnel-filters" method="get" action="<?php echo esc_url( get_permalink( 1381 ) ); ?>">
            <input type="hidden" name="directory_view" value="<?php echo esc_attr( $filters['directory_view'] ); ?>">

            <div class="wmrn-personnel-field wmrn-personnel-search">
                <label for="wmrn-personnel-search"><?php esc_html_e( 'Search', 'wmrn-personnel-authority' ); ?></label>
                <input id="wmrn-personnel-search" type="search" name="people_search" value="<?php echo esc_attr( $filters['search'] ); ?>" placeholder="<?php esc_attr_e( 'Name, on-air name, role…', 'wmrn-personnel-authority' ); ?>">
            </div>

            <?php if ( 'archive' !== $filters['directory_view'] ) : ?>
                <div class="wmrn-personnel-field">
                    <label for="wmrn-personnel-station"><?php esc_html_e( 'Station', 'wmrn-personnel-authority' ); ?></label>
                    <select id="wmrn-personnel-station" name="station">
                        <option value=""><?php esc_html_e( 'All stations', 'wmrn-personnel-authority' ); ?></option>
                        <?php foreach ( $stations as $slug => $label ) : ?>
                            <option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $filters['station'], $slug ); ?>><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="wmrn-personnel-field">
                    <label for="wmrn-personnel-role"><?php esc_html_e( 'Role', 'wmrn-personnel-authority' ); ?></label>
                    <select id="wmrn-personnel-role" name="role">
                        <option value=""><?php esc_html_e( 'All roles', 'wmrn-personnel-authority' ); ?></option>
                        <?php foreach ( $roles as $slug => $label ) : ?>
                            <option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $filters['role'], $slug ); ?>><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="wmrn-personnel-field">
                    <label for="wmrn-personnel-era"><?php esc_html_e( 'Era', 'wmrn-personnel-authority' ); ?></label>
                    <select id="wmrn-personnel-era" name="era">
                        <option value=""><?php esc_html_e( 'All eras', 'wmrn-personnel-authority' ); ?></option>
                        <?php for ( $decade = 1940; $decade <= 2020; $decade += 10 ) : ?>
                            <option value="<?php echo esc_attr( $decade ); ?>" <?php selected( (string) $filters['era'], (string) $decade ); ?>><?php echo esc_html( $decade . 's' ); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="wmrn-personnel-field">
                    <label for="wmrn-personnel-relationship"><?php esc_html_e( 'Affiliation', 'wmrn-personnel-authority' ); ?></label>
                    <select id="wmrn-personnel-relationship" name="relationship">
                        <option value=""><?php esc_html_e( 'All affiliations', 'wmrn-personnel-authority' ); ?></option>
                        <?php foreach ( $relationships as $slug => $label ) : ?>
                            <option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $filters['relationship'], $slug ); ?>><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <details class="wmrn-personnel-more-filters">
                    <summary><?php esc_html_e( 'More filters', 'wmrn-personnel-authority' ); ?></summary>
                    <div class="wmrn-personnel-more-grid">
                        <div class="wmrn-personnel-field">
                            <label for="wmrn-personnel-year"><?php esc_html_e( 'Specific year', 'wmrn-personnel-authority' ); ?></label>
                            <input id="wmrn-personnel-year" name="year" inputmode="numeric" pattern="[0-9]{4}" value="<?php echo esc_attr( $filters['year'] ); ?>" placeholder="1995">
                        </div>
                        <div class="wmrn-personnel-field">
                            <label for="wmrn-personnel-verification"><?php esc_html_e( 'Verification', 'wmrn-personnel-authority' ); ?></label>
                            <select id="wmrn-personnel-verification" name="verification">
                                <option value=""><?php esc_html_e( 'Any status', 'wmrn-personnel-authority' ); ?></option>
                                <?php foreach ( $verification as $slug => $label ) : ?>
                                    <option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $filters['verification'], $slug ); ?>><?php echo esc_html( $label ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="wmrn-personnel-field">
                            <label for="wmrn-personnel-employer"><?php esc_html_e( 'Employer / owner', 'wmrn-personnel-authority' ); ?></label>
                            <input id="wmrn-personnel-employer" name="employer" value="<?php echo esc_attr( $filters['employer'] ); ?>">
                        </div>
                        <div class="wmrn-personnel-field">
                            <label for="wmrn-personnel-department"><?php esc_html_e( 'Department', 'wmrn-personnel-authority' ); ?></label>
                            <input id="wmrn-personnel-department" name="department" value="<?php echo esc_attr( $filters['department'] ); ?>">
                        </div>
                    </div>
                </details>
            <?php endif; ?>

            <div class="wmrn-personnel-actions">
                <button type="submit" class="wmrn-personnel-submit"><?php esc_html_e( 'Apply filters', 'wmrn-personnel-authority' ); ?></button>
                <a class="wmrn-personnel-clear" href="<?php echo esc_url( wmrn_personnel_directory_url( [ 'directory_view' => $filters['directory_view'] ] ) ); ?>"><?php esc_html_e( 'Clear', 'wmrn-personnel-authority' ); ?></a>
            </div>
        </form>

        <p class="wmrn-personnel-result-count" aria-live="polite">
            <?php echo esc_html( sprintf( _n( '%s record shown', '%s records shown', count( $records ), 'wmrn-personnel-authority' ), number_format_i18n( count( $records ) ) ) ); ?>
        </p>

        <?php if ( ! $records ) : ?>
            <div class="wmrn-personnel-empty">
                <?php if ( 'personnel' === $filters['directory_view'] && 0 === $stats['personnel'] ) : ?>
                    <strong><?php esc_html_e( 'The Personnel Authority System is ready for researched records.', 'wmrn-personnel-authority' ); ?></strong>
                    <p><?php esc_html_e( 'Existing archive-linked people remain available under “People in the Archive” while verified staff records are added.', 'wmrn-personnel-authority' ); ?></p>
                <?php else : ?>
                    <strong><?php esc_html_e( 'No records match those filters.', 'wmrn-personnel-authority' ); ?></strong>
                    <p><?php esc_html_e( 'Try clearing one or more filters.', 'wmrn-personnel-authority' ); ?></p>
                <?php endif; ?>
            </div>
        <?php else : ?>
            <div class="wmrn-personnel-grid">
                <?php foreach ( $records as $record ) :
                    $term  = $record['term'];
                    $data  = $record['data'];
                    $name  = $record['name'];
                    $years = wmrn_personnel_years( $data );
                    $link  = $record['is_personnel'] ? wmrn_personnel_profile_url( $term ) : wmrn_personnel_archive_person_url( $term->term_id );

                    $station_labels = WMRN_Personnel_Authority::labels(
                        WMRN_Personnel_Authority::all_stations( $data ),
                        $stations
                    );
                    ?>
                    <a class="wmrn-personnel-card<?php echo $record['is_personnel'] ? ' is-personnel' : ' is-archive-person'; ?>" href="<?php echo esc_url( is_wp_error( $link ) ? '#' : $link ); ?>">
                        <div class="wmrn-personnel-card-media">
                            <?php if ( ! empty( $data['portrait_id'] ) ) : ?>
                                <?php echo wp_get_attachment_image( (int) $data['portrait_id'], 'thumbnail', false, [ 'class' => 'wmrn-personnel-photo', 'alt' => '' ] ); ?>
                            <?php else : ?>
                                <span class="wmrn-personnel-initials" aria-hidden="true"><?php echo esc_html( wmrn_personnel_initials( $name ) ); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="wmrn-personnel-card-body">
                            <h2><?php echo esc_html( $name ); ?></h2>
                            <?php if ( $data['on_air_name'] && 0 !== strcasecmp( $data['on_air_name'], $name ) ) : ?>
                                <p class="wmrn-personnel-muted"><?php echo esc_html( sprintf( __( 'On air as %s', 'wmrn-personnel-authority' ), $data['on_air_name'] ) ); ?></p>
                            <?php endif; ?>
                            <?php if ( $data['primary_role'] ) : ?>
                                <p class="wmrn-personnel-role"><?php echo esc_html( $data['primary_role'] ); ?></p>
                            <?php elseif ( ! $record['is_personnel'] ) : ?>
                                <p class="wmrn-personnel-role"><?php esc_html_e( 'Person in the archive', 'wmrn-personnel-authority' ); ?></p>
                            <?php endif; ?>
                            <?php if ( $years ) : ?>
                                <p class="wmrn-personnel-muted"><?php echo esc_html( $years ); ?></p>
                            <?php endif; ?>
                            <?php if ( $station_labels ) : ?>
                                <div class="wmrn-personnel-badges" aria-label="<?php esc_attr_e( 'Station affiliations', 'wmrn-personnel-authority' ); ?>">
                                    <?php foreach ( $station_labels as $label ) : ?>
                                        <span class="wmrn-personnel-badge"><?php echo esc_html( $label ); ?></span>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                            <p class="wmrn-personnel-accession-count">
                                <?php echo esc_html( sprintf( _n( '%s linked accession', '%s linked accessions', (int) $term->count, 'wmrn-personnel-authority' ), number_format_i18n( (int) $term->count ) ) ); ?>
                            </p>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="wmrn-personnel-research-note">
            <strong><?php esc_html_e( 'Research note:', 'wmrn-personnel-authority' ); ?></strong>
            <?php esc_html_e( 'This is a developing historical directory. Employment dates, titles, station assignments, and spellings are recorded from available evidence and may be refined as additional staff lists, newspapers, recordings, photographs, and first-person sources are identified.', 'wmrn-personnel-authority' ); ?>
        </div>
    </div>
</section>
<?php
get_footer();
