<?php
defined( 'ABSPATH' ) || exit;

get_header();

$term = WMRN_Personnel_Integration::profile_term();
if ( ! $term ) {
    status_header( 404 );
    get_template_part( '404' );
    get_footer();
    return;
}
$data = WMRN_Personnel_Authority::public_data( $term->term_id );
$name = wmrn_personnel_display_name( $term, $data );

$stations      = WMRN_Personnel_Authority::stations();
$roles         = WMRN_Personnel_Authority::roles();
$relationships = WMRN_Personnel_Authority::relationships();
$verification  = WMRN_Personnel_Authority::verification();

$station_labels = WMRN_Personnel_Authority::labels( WMRN_Personnel_Authority::all_stations( $data ), $stations );
$role_labels    = WMRN_Personnel_Authority::labels( WMRN_Personnel_Authority::all_roles( $data ), $roles );
$years          = wmrn_personnel_years( $data );
$hero_bg        = function_exists( 'wmrn_get' ) && function_exists( 'wmrn_asset' )
    ? wmrn_get( 'wmrn_people_hero_image', wmrn_asset( 'images/hero-people.jpg' ) )
    : '';
?>
<section class="page-hero wmrn-personnel-hero">
    <?php if ( $hero_bg ) : ?>
        <img src="<?php echo esc_url( $hero_bg ); ?>" class="page-hero-bg" alt="" aria-hidden="true">
    <?php endif; ?>
    <div class="page-hero-overlay"></div>
    <div class="page-hero-content">
        <p class="hero-eyebrow"><?php esc_html_e( 'WMRN Personnel Profile', 'wmrn-personnel-authority' ); ?></p>
        <h1 class="page-hero-title"><?php echo esc_html( $name ); ?></h1>
        <p class="page-hero-subtitle">
            <?php
            if ( $data['primary_role'] ) {
                echo esc_html( $data['primary_role'] . ( $years ? ' • ' . $years : '' ) );
            } elseif ( $years ) {
                echo esc_html( 'WMRN Studios • ' . $years );
            } else {
                esc_html_e( 'Historical personnel authority record', 'wmrn-personnel-authority' );
            }
            ?>
        </p>
    </div>
</section>

<section class="wmrn-personnel-profile">
    <div class="wmrn-container">
        <p><a class="wmrn-personnel-back" href="<?php echo esc_url( get_permalink( 1381 ) ); ?>">← <?php esc_html_e( 'Back to WMRN Personnel Directory', 'wmrn-personnel-authority' ); ?></a></p>

        <div class="wmrn-personnel-profile-grid">
            <aside class="wmrn-personnel-profile-sidebar" aria-label="<?php esc_attr_e( 'Personnel summary', 'wmrn-personnel-authority' ); ?>">
                <?php if ( $data['portrait_id'] ) : ?>
                    <?php echo wp_get_attachment_image( (int) $data['portrait_id'], 'large', false, [ 'class' => 'wmrn-personnel-profile-photo', 'alt' => $name ] ); ?>
                <?php else : ?>
                    <div class="wmrn-personnel-profile-initials" aria-hidden="true"><?php echo esc_html( wmrn_personnel_initials( $name ) ); ?></div>
                <?php endif; ?>

                <dl class="wmrn-personnel-facts">
                    <?php if ( $data['on_air_name'] && 0 !== strcasecmp( $data['on_air_name'], $name ) ) : ?>
                        <dt><?php esc_html_e( 'On-air / professional name', 'wmrn-personnel-authority' ); ?></dt>
                        <dd><?php echo esc_html( $data['on_air_name'] ); ?></dd>
                    <?php endif; ?>

                    <?php if ( $years ) : ?>
                        <dt><?php esc_html_e( 'Known service', 'wmrn-personnel-authority' ); ?></dt>
                        <dd><?php echo esc_html( $years ); ?></dd>
                    <?php endif; ?>

                    <?php if ( $data['primary_role'] ) : ?>
                        <dt><?php esc_html_e( 'Primary display role', 'wmrn-personnel-authority' ); ?></dt>
                        <dd><?php echo esc_html( $data['primary_role'] ); ?></dd>
                    <?php endif; ?>

                    <?php if ( $station_labels ) : ?>
                        <dt><?php esc_html_e( 'Stations', 'wmrn-personnel-authority' ); ?></dt>
                        <dd><?php echo esc_html( implode( ', ', $station_labels ) ); ?></dd>
                    <?php endif; ?>

                    <?php if ( $role_labels ) : ?>
                        <dt><?php esc_html_e( 'Roles', 'wmrn-personnel-authority' ); ?></dt>
                        <dd><?php echo esc_html( implode( ', ', $role_labels ) ); ?></dd>
                    <?php endif; ?>

                    <?php if ( $data['department'] ) : ?>
                        <dt><?php esc_html_e( 'Department', 'wmrn-personnel-authority' ); ?></dt>
                        <dd><?php echo esc_html( $data['department'] ); ?></dd>
                    <?php endif; ?>

                    <?php if ( $data['employer'] ) : ?>
                        <dt><?php esc_html_e( 'Employer / ownership company', 'wmrn-personnel-authority' ); ?></dt>
                        <dd><?php echo esc_html( $data['employer'] ); ?></dd>
                    <?php endif; ?>

                    <?php if ( $data['relationship'] && isset( $relationships[ $data['relationship'] ] ) ) : ?>
                        <dt><?php esc_html_e( 'Relationship to WMRN', 'wmrn-personnel-authority' ); ?></dt>
                        <dd><?php echo esc_html( $relationships[ $data['relationship'] ] ); ?></dd>
                    <?php endif; ?>

                    <dt><?php esc_html_e( 'Verification', 'wmrn-personnel-authority' ); ?></dt>
                    <dd><?php echo esc_html( $verification[ $data['verification'] ] ?? __( 'Research needed', 'wmrn-personnel-authority' ) ); ?></dd>
                </dl>
            </aside>

            <main class="wmrn-personnel-profile-main">
                <section aria-labelledby="wmrn-career-heading">
                    <h2 id="wmrn-career-heading"><?php esc_html_e( 'WMRN Career', 'wmrn-personnel-authority' ); ?></h2>
                    <?php if ( $data['biography'] ) : ?>
                        <div class="wmrn-personnel-prose"><?php echo wp_kses_post( wpautop( $data['biography'] ) ); ?></div>
                    <?php else : ?>
                        <p class="wmrn-personnel-prose"><?php esc_html_e( 'This personnel record is being expanded as additional documentation is reviewed.', 'wmrn-personnel-authority' ); ?></p>
                    <?php endif; ?>
                </section>

                <?php if ( $data['assignments'] ) : ?>
                    <section class="wmrn-personnel-assignments" aria-labelledby="wmrn-assignments-heading">
                        <h2 id="wmrn-assignments-heading"><?php esc_html_e( 'Career Assignments', 'wmrn-personnel-authority' ); ?></h2>
                        <div class="wmrn-personnel-timeline">
                            <?php foreach ( $data['assignments'] as $row ) :
                                $station = $row['station'] && isset( $stations[ $row['station'] ] ) ? $stations[ $row['station'] ] : '';
                                $role    = $row['role_label'] ?: ( $row['role'] && isset( $roles[ $row['role'] ] ) ? $roles[ $row['role'] ] : '' );
                                $date    = wmrn_personnel_assignment_date_label( $row );
                                ?>
                                <article class="wmrn-personnel-assignment">
                                    <p class="wmrn-personnel-assignment-date"><?php echo esc_html( $date ); ?></p>
                                    <h3>
                                        <?php
                                        $heading = array_filter( [ $role, $station ] );
                                        echo esc_html( $heading ? implode( ' — ', $heading ) : __( 'Documented assignment', 'wmrn-personnel-authority' ) );
                                        ?>
                                    </h3>
                                    <dl>
                                        <?php if ( $row['department'] ) : ?><dt><?php esc_html_e( 'Department', 'wmrn-personnel-authority' ); ?></dt><dd><?php echo esc_html( $row['department'] ); ?></dd><?php endif; ?>
                                        <?php if ( $row['employer'] ) : ?><dt><?php esc_html_e( 'Employer', 'wmrn-personnel-authority' ); ?></dt><dd><?php echo esc_html( $row['employer'] ); ?></dd><?php endif; ?>
                                        <?php if ( $row['relationship'] && isset( $relationships[ $row['relationship'] ] ) ) : ?><dt><?php esc_html_e( 'Affiliation', 'wmrn-personnel-authority' ); ?></dt><dd><?php echo esc_html( $relationships[ $row['relationship'] ] ); ?></dd><?php endif; ?>
                                        <?php if ( $row['workplace'] ) : ?><dt><?php esc_html_e( 'Workplace', 'wmrn-personnel-authority' ); ?></dt><dd><?php echo esc_html( $row['workplace'] ); ?></dd><?php endif; ?>
                                        <?php if ( $row['verification'] && isset( $verification[ $row['verification'] ] ) ) : ?><dt><?php esc_html_e( 'Verification', 'wmrn-personnel-authority' ); ?></dt><dd><?php echo esc_html( $verification[ $row['verification'] ] ); ?></dd><?php endif; ?>
                                    </dl>
                                    <?php if ( $row['notes'] ) : ?><p><?php echo nl2br( esc_html( $row['notes'] ) ); ?></p><?php endif; ?>
                                    <?php if ( $row['source'] ) : ?><p class="wmrn-personnel-source"><strong><?php esc_html_e( 'Source:', 'wmrn-personnel-authority' ); ?></strong> <?php echo nl2br( esc_html( $row['source'] ) ); ?></p><?php endif; ?>
                                    <?php if ( 'documented' === $row['date_type'] ) : ?><p class="wmrn-personnel-evidence-note"><?php esc_html_e( 'The dates above document this role at those points in time; they do not establish continuous employment between them.', 'wmrn-personnel-authority' ); ?></p><?php endif; ?>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    </section>
                <?php endif; ?>

                <?php if ( $data['timeline'] ) : ?>
                    <section aria-labelledby="wmrn-timeline-heading">
                        <h2 id="wmrn-timeline-heading"><?php esc_html_e( 'Additional Career Timeline', 'wmrn-personnel-authority' ); ?></h2>
                        <div class="wmrn-personnel-prose"><?php echo wp_kses_post( wpautop( $data['timeline'] ) ); ?></div>
                    </section>
                <?php endif; ?>

                <?php if ( $data['sources'] ) : ?>
                    <section aria-labelledby="wmrn-sources-heading">
                        <h2 id="wmrn-sources-heading"><?php esc_html_e( 'Sources & Documentation', 'wmrn-personnel-authority' ); ?></h2>
                        <div class="wmrn-personnel-sources"><?php echo nl2br( esc_html( $data['sources'] ) ); ?></div>
                    </section>
                <?php endif; ?>

                <section class="wmrn-personnel-related" aria-labelledby="wmrn-related-heading">
                    <h2 id="wmrn-related-heading"><?php esc_html_e( 'Related Materials in the Archive', 'wmrn-personnel-authority' ); ?></h2>
                    <?php wmrn_personnel_render_related_accessions( $term->term_id ); ?>
                </section>
            </main>
        </div>
    </div>
</section>
<?php
get_footer();
