<?php
defined( 'ABSPATH' ) || exit;

final class WMRN_Personnel_Admin {
    public static function boot() {
        $taxonomy = WMRN_Personnel_Authority::taxonomy();
        add_action( $taxonomy . '_edit_form_fields', [ __CLASS__, 'fields' ] );
        add_action( 'edited_' . $taxonomy, [ __CLASS__, 'save' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'assets' ] );
        add_filter( 'manage_edit-' . $taxonomy . '_columns', [ __CLASS__, 'columns' ] );
        add_filter( 'manage_' . $taxonomy . '_custom_column', [ __CLASS__, 'column' ], 10, 3 );
        add_action( 'admin_menu', [ __CLASS__, 'menu' ], 50 );
    }
    public static function menu() {
        $taxonomy = WMRN_Personnel_Authority::taxonomy();
        $tax = get_taxonomy( $taxonomy );
        if ( $tax ) {
            add_management_page(
                'WMRN Personnel Authority System',
                'WMRN Personnel Authority',
                $tax->cap->manage_terms,
                'wmrn-personnel-authority',
                [ __CLASS__, 'authority_page' ]
            );
        }
    }
    public static function authority_page() {
        $taxonomy = WMRN_Personnel_Authority::taxonomy();
        $search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
        $args = [
            'taxonomy'   => $taxonomy,
            'hide_empty' => false,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ];
        if ( '' !== $search ) {
            $args['search'] = $search;
        }
        $terms = get_terms( $args );
        if ( is_wp_error( $terms ) ) {
            $terms = [];
        }

        echo '<div class="wrap"><h1>WMRN Personnel Authority System</h1>';
        echo '<p>This screen expands existing Tainacan People authority records. It does not create a second person database or change accession relationships.</p>';
        echo '<form method="get" style="margin:16px 0 20px"><input type="hidden" name="page" value="wmrn-personnel-authority">';
        echo '<label class="screen-reader-text" for="wmrn-pa-search">Search existing People</label>';
        echo '<input id="wmrn-pa-search" type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="Search existing People…" style="min-width:320px"> ';
        submit_button( 'Search', 'secondary', '', false );
        if ( '' !== $search ) {
            echo ' <a class="button" href="' . esc_url( admin_url( 'tools.php?page=wmrn-personnel-authority' ) ) . '">Clear</a>';
        }
        echo '</form>';

        echo '<table class="widefat striped"><thead><tr><th>Name</th><th>Personnel?</th><th>Years</th><th>Stations</th><th>Linked accessions</th><th></th></tr></thead><tbody>';
        if ( ! $terms ) {
            echo '<tr><td colspan="6">No existing People authority records matched.</td></tr>';
        }
        foreach ( $terms as $term ) {
            $data = WMRN_Personnel_Authority::get( $term->term_id );
            $years = trim( (string) $data['start_year'] );
            if ( $data['end_year'] ) {
                $years .= ( $years ? '–' : 'Through ' ) . $data['end_year'];
            } elseif ( $years ) {
                $years .= '–';
            }
            $stations = WMRN_Personnel_Authority::labels(
                WMRN_Personnel_Authority::all_stations( $data ),
                WMRN_Personnel_Authority::stations()
            );
            $edit = admin_url(
                'term.php?taxonomy=' . rawurlencode( $taxonomy ) .
                '&tag_ID=' . (int) $term->term_id .
                '&post_type=' . rawurlencode( WMRN_Personnel_Authority::collection_post_type() )
            );
            echo '<tr>';
            echo '<td><strong>' . esc_html( $term->name ) . '</strong></td>';
            echo '<td>' . ( $data['is_personnel'] ? '<strong>Yes</strong>' : '—' ) . '</td>';
            echo '<td>' . esc_html( $years ?: '—' ) . '</td>';
            echo '<td>' . esc_html( $stations ? implode( ', ', $stations ) : '—' ) . '</td>';
            echo '<td>' . esc_html( number_format_i18n( (int) $term->count ) ) . '</td>';
            echo '<td><a class="button" href="' . esc_url( $edit ) . '">Edit authority record</a></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
        echo '<p style="margin-top:16px"><strong>Authority rule:</strong> search for an existing person before creating any new Tainacan People term.</p>';
        echo '</div>';
    }
    public static function assets() {
        $screen = get_current_screen();
        if ( ! $screen || WMRN_Personnel_Authority::taxonomy() !== $screen->taxonomy ) { return; }
        wp_enqueue_media();
        wp_enqueue_style( 'wmrn-personnel-admin', WMRN_PERSONNEL_URL . 'assets/admin.css', [], WMRN_PERSONNEL_VERSION );
        wp_enqueue_script( 'wmrn-personnel-admin', WMRN_PERSONNEL_URL . 'assets/admin.js', [ 'media-views' ], WMRN_PERSONNEL_VERSION, true );
    }
    public static function add_hint() {
        echo '<p>To expand an existing person, open their name in the list. Personnel fields and career assignments are available on the edit screen. Search existing People before adding a name.</p>';
    }
    public static function control( $key, $label, $value, $type = 'text', $choices = [], $prefix = 'wmrn_personnel', $id_prefix = 'wmrn-pa-' ) {
        $id = $id_prefix . $key;
        $name = $prefix . '[' . $key . ']';
        echo '<div class="wmrn-pa-field"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label>';
        if ( 'textarea' === $type ) {
            echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="5">' . esc_textarea( $value ) . '</textarea>';
        } elseif ( 'select' === $type ) {
            echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '"><option value="">Not recorded</option>';
            foreach ( $choices as $slug => $text ) { echo '<option value="' . esc_attr( $slug ) . '"' . selected( $value, $slug, false ) . '>' . esc_html( $text ) . '</option>'; }
            echo '</select>';
        } elseif ( 'checkbox' === $type ) {
            echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="0"><input id="' . esc_attr( $id ) . '" type="checkbox" name="' . esc_attr( $name ) . '" value="1"' . checked( (bool) $value, true, false ) . '>';
        } else {
            echo '<input id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" type="' . esc_attr( $type ) . '" value="' . esc_attr( $value ) . '"' . ( 'number' === $type ? ' min="0" step="1"' : '' ) . '>';
        }
        echo '</div>';
    }
    public static function multichoice( $key, $label, $selected, $choices ) {
        echo '<fieldset class="wmrn-pa-choices"><legend>' . esc_html( $label ) . '</legend>';
        foreach ( $choices as $slug => $text ) {
            echo '<label><input type="checkbox" name="wmrn_personnel[' . esc_attr( $key ) . '][]" value="' . esc_attr( $slug ) . '"' . checked( in_array( $slug, $selected, true ), true, false ) . '> ' . esc_html( $text ) . '</label>';
        }
        echo '</fieldset>';
    }
    public static function assignment( $index, $row ) {
        $row = array_replace( WMRN_Personnel_Authority::assignment_defaults(), $row );
        $prefix = 'wmrn_personnel[assignments][' . $index . ']';
        $id = 'wmrn-pa-assignment-' . $index . '-';
        echo '<fieldset class="wmrn-pa-assignment"><legend>Career assignment <span class="wmrn-pa-number">' . esc_html( is_numeric( $index ) ? $index + 1 : '' ) . '</span></legend><div class="wmrn-pa-fields">';
        self::control( 'station', 'Station', $row['station'], 'select', WMRN_Personnel_Authority::stations(), $prefix, $id );
        self::control( 'role', 'Role', $row['role'], 'select', WMRN_Personnel_Authority::roles(), $prefix, $id );
        self::control( 'role_label', 'Documented job title (optional)', $row['role_label'], 'text', [], $prefix, $id );
        self::control( 'department', 'Department', $row['department'], 'text', [], $prefix, $id );
        self::control( 'date_type', 'What do the dates establish?', $row['date_type'], 'select', [ 'tenure' => 'Documented employment period', 'documented' => 'Role documented on these dates only' ], $prefix, $id );
        self::control( 'start', 'Start / first documented date', $row['start'], 'text', [], $prefix, $id );
        self::control( 'end', 'End / second documented date', $row['end'], 'text', [], $prefix, $id );
        self::control( 'employer', 'Employer / company', $row['employer'], 'text', [], $prefix, $id );
        self::control( 'relationship', 'Relationship to WMRN', $row['relationship'], 'select', WMRN_Personnel_Authority::relationships(), $prefix, $id );
        self::control( 'workplace', 'Documented workplace (optional)', $row['workplace'], 'text', [], $prefix, $id );
        self::control( 'verification', 'Assignment verification', $row['verification'], 'select', WMRN_Personnel_Authority::verification(), $prefix, $id );
        self::control( 'notes', 'Public assignment notes', $row['notes'], 'textarea', [], $prefix, $id );
        self::control( 'source', 'Public source / documentation reference', $row['source'], 'textarea', [], $prefix, $id );
        echo '</div><button type="button" class="button wmrn-pa-remove">Remove this assignment</button></fieldset>';
    }
    public static function fields( $term ) {
        if ( ! current_user_can( 'edit_term', $term->term_id ) ) { return; }
        $d = WMRN_Personnel_Authority::get( $term->term_id );
        echo '<tr><th scope="row">Personnel Authority System</th><td><div class="wmrn-pa-editor">';
        wp_nonce_field( 'wmrn_personnel_' . $term->term_id, 'wmrn_personnel_nonce' );
        echo '<input type="hidden" name="wmrn_personnel_version" value="' . esc_attr( WMRN_Personnel_Authority::version( WMRN_Personnel_Authority::raw( $term->term_id ) ) ) . '">';
        echo '<p>This is the same People authority used by accessions. Leave unknown facts blank. Directory inclusion is an explicit editorial decision; appearing in an accession does not establish employment.</p>';
        self::control( 'is_personnel', 'Include in WMRN Personnel Directory', $d['is_personnel'], 'checkbox' );
        echo '<h3>Identification and employment</h3><div class="wmrn-pa-fields">';
        foreach ( [ 'display_name' => 'Display name (blank uses People name)', 'sort_name' => 'Sort name (e.g. Cole, Terry)', 'on_air_name' => 'On-air / professional name', 'primary_role' => 'Primary Display Role', 'start_year' => 'Earliest known employment start year', 'end_year' => 'Latest known employment end year', 'employer' => 'Employer / ownership company', 'department' => 'Department' ] as $key => $label ) { self::control( $key, $label, $d[$key] ); }
        self::control( 'relationship', 'Relationship to WMRN', $d['relationship'], 'select', WMRN_Personnel_Authority::relationships() );
        self::control( 'portrait_id', 'Portrait / staff photograph media ID', $d['portrait_id'], 'number' );
        echo '</div><p><button type="button" class="button" id="wmrn-pa-portrait-select">Select portrait</button> <button type="button" class="button" id="wmrn-pa-portrait-clear">Clear portrait</button></p><div id="wmrn-pa-portrait-preview">';
        if ( $d['portrait_id'] ) { echo wp_get_attachment_image( $d['portrait_id'], 'thumbnail' ); }
        echo '</div><p>Employment bounds describe known service, not an assumed continuous career. Use assignments below for gaps, changing stations, overlapping roles and dated evidence.</p>';
        self::multichoice( 'stations', 'Station affiliations (when documented)', $d['stations'], WMRN_Personnel_Authority::stations() );
        self::multichoice( 'roles', 'Roles', $d['roles'], WMRN_Personnel_Authority::roles() );
        echo '<h3>Career assignments</h3><p>Dates: YYYY, YYYY-MM, or YYYY-MM-DD. Blank means unknown, never “present.” For evidence of a role on a specific date, choose “Role documented on these dates only.” Station and workplace are separate facts. All assignment notes and citations are public.</p><div id="wmrn-pa-assignments">';
        $assignment_rows = $d['assignments'] ?: [ [] ];
        foreach ( $assignment_rows as $index => $row ) { self::assignment( $index, $row ); }
        echo '</div><template id="wmrn-pa-assignment-template">'; self::assignment( '__INDEX__', [] ); echo '</template>';
        echo '<p><button type="button" class="button" id="wmrn-pa-add">Add career assignment</button></p><p id="wmrn-pa-status" class="screen-reader-text" aria-live="polite"></p>';
        echo '<h3>Public historical record</h3>';
        self::control( 'biography', 'Career biography (basic HTML allowed)', $d['biography'], 'textarea' );
        self::control( 'timeline', 'Additional career timeline (basic HTML allowed)', $d['timeline'], 'textarea' );
        self::control( 'sources', 'Public sources & documentation (citations and URLs)', $d['sources'], 'textarea' );
        self::control( 'verification', 'Verification status', $d['verification'], 'select', WMRN_Personnel_Authority::verification() );
        self::control( 'featured', 'Featured personnel record', $d['featured'], 'checkbox' );
        echo '<h3>Private research</h3><p>Internal notes are available only to editors. They are excluded from public profiles, directory search and core REST responses.</p>';
        self::control( 'internal_notes', 'Internal research notes — never public', $d['internal_notes'], 'textarea' );
        echo '<input type="hidden" name="wmrn_personnel_complete" value="1"></div></td></tr>';
    }
    public static function save( $id ) {
        if ( ! isset( $_POST['wmrn_personnel_nonce'] ) ) { return; }
        if ( ! is_string( $_POST['wmrn_personnel_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wmrn_personnel_nonce'] ) ), 'wmrn_personnel_' . $id ) || ! current_user_can( 'edit_term', $id ) ) { return; }
        if ( empty( $_POST['wmrn_personnel_complete'] ) ) { wp_die( 'The personnel form was truncated. No personnel changes were saved. Go back and reduce the number of rows.', '', [ 'back_link' => true ] ); }
        $input = isset( $_POST['wmrn_personnel'] ) && is_array( $_POST['wmrn_personnel'] ) ? wp_unslash( $_POST['wmrn_personnel'] ) : [];
        $version = isset( $_POST['wmrn_personnel_version'] ) && is_string( $_POST['wmrn_personnel_version'] ) ? sanitize_text_field( wp_unslash( $_POST['wmrn_personnel_version'] ) ) : '';
        $result = WMRN_Personnel_Authority::save( $id, $input, $version );
        if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ), 'Personnel record not saved', [ 'back_link' => true ] ); }
    }
    public static function columns( $columns ) {
        return array_merge( $columns, [ 'wmrn_personnel' => 'Personnel?', 'wmrn_years' => 'Years', 'wmrn_stations' => 'Stations', 'wmrn_role' => 'Primary Role', 'wmrn_verification' => 'Verification' ] );
    }
    public static function column( $content, $column, $id ) {
        if ( 0 !== strpos( $column, 'wmrn_' ) ) { return $content; }
        $d = WMRN_Personnel_Authority::public_data( $id );
        if ( 'wmrn_personnel' === $column ) { return $d['is_personnel'] ? 'Yes' : '—'; }
        if ( ! $d['is_personnel'] ) { return '—'; }
        $values = [ 'wmrn_years' => wmrn_personnel_years( $d ), 'wmrn_stations' => implode( ', ', WMRN_Personnel_Authority::labels( WMRN_Personnel_Authority::all_stations( $d ), WMRN_Personnel_Authority::stations() ) ), 'wmrn_role' => $d['primary_role'], 'wmrn_verification' => WMRN_Personnel_Authority::verification()[$d['verification']] ?? '' ];
        return esc_html( $values[$column] ?? $content );
    }
}
