<?php
defined( 'ABSPATH' ) || exit;

function wmrn_personnel_display_name( $term, $data = null ) {
    $data = is_array( $data ) ? $data : WMRN_Personnel_Authority::public_data( $term->term_id );
    $name = trim( (string) ( $data['display_name'] ?? '' ) );
    if ( '' === $name ) {
        $name = preg_replace( '/^performer\s+/i', '', (string) $term->name );
        $name = trim( $name, " \t\n\r\0\x0B\"'" );
    }
    return $name;
}

function wmrn_personnel_years( $data ) {
    $start = trim( (string) ( $data['start_year'] ?? '' ) );
    $end   = trim( (string) ( $data['end_year'] ?? '' ) );
    if ( $start && $end ) {
        return $start === $end ? $start : $start . '–' . $end;
    }
    if ( $start ) {
        return $start . '–';
    }
    if ( $end ) {
        return 'Through ' . $end;
    }
    return '';
}

function wmrn_personnel_initials( $name ) {
    $parts = preg_split( '/\s+/u', trim( (string) $name ) );
    $out   = '';
    foreach ( array_slice( (array) $parts, 0, 2 ) as $part ) {
        $out .= function_exists( 'mb_substr' ) ? mb_substr( $part, 0, 1 ) : substr( $part, 0, 1 );
    }
    return strtoupper( $out ?: '?' );
}

function wmrn_personnel_classify_people_term( $name ) {
    $raw   = trim( (string) $name );
    $plain = strtolower( str_replace( [ '“', '”', '’', '–', '—' ], [ '"', '"', "'", '-', '-' ], $raw ) );

    if ( '' === $plain || preg_match( '/^(unknown|unidentified)(\b|\s|\()/i', $raw ) ) {
        return 'unknown';
    }
    if ( preg_match( '/^[\"\']|[\"\']$/', $raw ) || preg_match( '/\b(ohio|cincinnati|marion)\)$/i', $raw ) ) {
        return 'review';
    }
    if ( preg_match( '/\b(wmrn|radio|am\/fm|wocb|wmfd|associated press|museum|company|corporation|corp\.?|club|church|school|program|office|auditor|treasurer|newspaper|publisher|network|television|station|staff|country|buckeye|marion star|galion concert band|cadets|match corp|hiking club|nazarene)\b/i', $plain ) ) {
        return 'organization';
    }
    if ( preg_match( '/\b(marion|cincinnati|ohio)\b/i', $plain ) && ! preg_match( '/\b(nixon|mason|wilson|cole|evers|guthery|klein|serling|house|west)\b/i', $plain ) ) {
        return 'place';
    }
    if ( preg_match( '/^performer\s+/i', $raw ) ) {
        return 'person';
    }
    if ( preg_match( "/^[A-Z][A-Za-z.\'’\-]+(?:\s+[A-Z]\.)?(?:\s+[A-Z][A-Za-z.\'’\-]+){1,3}$/u", $raw ) ) {
        return 'person';
    }
    return 'review';
}

function wmrn_personnel_filters() {
    $source = wp_unslash( $_GET );
    $view = isset( $source['directory_view'] ) ? sanitize_key( $source['directory_view'] ) : 'personnel';
    if ( ! in_array( $view, [ 'personnel', 'archive', 'combined' ], true ) ) {
        $view = 'personnel';
    }
    $filters = [
        'directory_view' => $view,
        'search'         => isset( $source['people_search'] ) ? sanitize_text_field( $source['people_search'] ) : '',
        'station'        => isset( $source['station'] ) ? sanitize_key( $source['station'] ) : '',
        'role'           => isset( $source['role'] ) ? sanitize_key( $source['role'] ) : '',
        'era'            => isset( $source['era'] ) ? preg_replace( '/\D+/', '', (string) $source['era'] ) : '',
        'year'           => isset( $source['year'] ) ? preg_replace( '/\D+/', '', (string) $source['year'] ) : '',
        'relationship'   => isset( $source['relationship'] ) ? sanitize_key( $source['relationship'] ) : '',
        'verification'   => isset( $source['verification'] ) ? sanitize_key( $source['verification'] ) : '',
        'employer'       => isset( $source['employer'] ) ? sanitize_text_field( $source['employer'] ) : '',
        'department'     => isset( $source['department'] ) ? sanitize_text_field( $source['department'] ) : '',
    ];
    if ( $filters['era'] && ( (int) $filters['era'] < 1800 || (int) $filters['era'] > 2190 ) ) {
        $filters['era'] = '';
    }
    if ( $filters['year'] && ( (int) $filters['year'] < 1800 || (int) $filters['year'] > 2199 ) ) {
        $filters['year'] = '';
    }
    return $filters;
}

function wmrn_personnel_search_matches( $term, $data, $search ) {
    if ( '' === $search ) {
        return true;
    }
    $parts = [
        $term->name,
        $data['display_name'] ?? '',
        $data['sort_name'] ?? '',
        $data['on_air_name'] ?? '',
        $data['primary_role'] ?? '',
        $data['department'] ?? '',
        $data['employer'] ?? '',
        wp_strip_all_tags( $data['biography'] ?? '' ),
        wp_strip_all_tags( $data['timeline'] ?? '' ),
    ];
    foreach ( (array) ( $data['assignments'] ?? [] ) as $row ) {
        foreach ( [ 'role_label', 'department', 'employer', 'workplace', 'notes', 'source' ] as $key ) {
            $parts[] = $row[ $key ] ?? '';
        }
    }
    return false !== stripos( implode( ' ', $parts ), $search );
}

function wmrn_personnel_published_counts( $term_ids ) {
    $term_ids = array_values( array_unique( array_filter( array_map( 'intval', (array) $term_ids ) ) ) );
    if ( ! $term_ids ) {
        return [];
    }

    global $wpdb;

    $placeholders = implode( ',', array_fill( 0, count( $term_ids ), '%d' ) );
    $sql = "
        SELECT tt.term_id, COUNT(DISTINCT p.ID) AS published_count
        FROM {$wpdb->term_taxonomy} tt
        INNER JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id = tt.term_taxonomy_id
        INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id
        WHERE tt.taxonomy = %s
          AND p.post_type = %s
          AND p.post_status = 'publish'
          AND tt.term_id IN ($placeholders)
        GROUP BY tt.term_id
    ";

    $args = array_merge(
        [ WMRN_Personnel_Authority::taxonomy(), WMRN_Personnel_Authority::collection_post_type() ],
        $term_ids
    );

    $rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
    $counts = array_fill_keys( $term_ids, 0 );

    foreach ( (array) $rows as $row ) {
        $counts[ (int) $row['term_id'] ] = (int) $row['published_count'];
    }

    return $counts;
}

function wmrn_personnel_directory_records( $filters ) {
    $terms = get_terms( [
        'taxonomy'   => WMRN_Personnel_Authority::taxonomy(),
        'hide_empty' => false,
        'orderby'    => 'name',
        'order'      => 'ASC',
    ] );
    if ( is_wp_error( $terms ) ) {
        return [ 'records' => [], 'stats' => [ 'personnel' => 0, 'archive_people' => 0, 'stations' => 0, 'linked_accessions' => 0 ] ];
    }

    $records       = [];
    $staff_count   = 0;
    $archive_count = 0;
    $linked        = 0;
    $stations_seen = [];
    $published_counts = wmrn_personnel_published_counts( wp_list_pluck( $terms, 'term_id' ) );

    foreach ( $terms as $term ) {
        $published_count = (int) ( $published_counts[ (int) $term->term_id ] ?? 0 );
        $term->count     = $published_count;
        $data              = WMRN_Personnel_Authority::public_data( $term->term_id );
        $is_personnel      = ! empty( $data['is_personnel'] );
        $is_archive_person = $published_count > 0 && 'person' === wmrn_personnel_classify_people_term( $term->name );

        if ( $is_personnel ) {
            ++$staff_count;
            $linked += $published_count;
            foreach ( WMRN_Personnel_Authority::all_stations( $data ) as $slug ) {
                $stations_seen[ $slug ] = true;
            }
        }
        if ( $is_archive_person ) {
            ++$archive_count;
        }

        $include = ( 'personnel' === $filters['directory_view'] && $is_personnel )
            || ( 'archive' === $filters['directory_view'] && $is_archive_person )
            || ( 'combined' === $filters['directory_view'] && ( $is_personnel || $is_archive_person ) );

        if ( ! $include || ! wmrn_personnel_search_matches( $term, $data, $filters['search'] ) ) {
            continue;
        }

        $career_filter = [
            'station'      => $filters['station'],
            'role'         => $filters['role'],
            'era'          => $filters['era'],
            'year'         => $filters['year'],
            'relationship' => $filters['relationship'],
            'verification' => $filters['verification'],
            'employer'     => $filters['employer'],
            'department'   => $filters['department'],
        ];
        if ( array_filter( $career_filter, 'strlen' ) && ! WMRN_Personnel_Authority::matches( $data, $career_filter ) ) {
            continue;
        }

        $name = wmrn_personnel_display_name( $term, $data );
        $records[] = [
            'term'              => $term,
            'data'              => $data,
            'name'              => $name,
            'is_personnel'      => $is_personnel,
            'is_archive_person' => $is_archive_person,
            'sort'              => strtolower( $data['sort_name'] ?: $name ),
        ];
    }

    usort( $records, static function( $a, $b ) {
        return strcasecmp( $a['sort'], $b['sort'] );
    } );

    return [
        'records' => $records,
        'stats'   => [
            'personnel'         => $staff_count,
            'archive_people'    => $archive_count,
            'stations'          => count( $stations_seen ),
            'linked_accessions' => $linked,
        ],
    ];
}

function wmrn_personnel_profile_url( $term ) {
    $slug = is_object( $term ) ? $term->slug : (string) $term;
    return home_url( user_trailingslashit( WMRN_Personnel_Integration::DIRECTORY_SLUG . '/' . rawurlencode( $slug ) ) );
}

function wmrn_personnel_archive_person_url( $term_id ) {
    return add_query_arg( [
        'taxquery' => [
            [
                'compare'  => 'IN',
                'taxonomy' => WMRN_Personnel_Authority::taxonomy(),
                'terms'    => [ (int) $term_id ],
            ],
        ],
    ], home_url( '/archive/' ) );
}

function wmrn_personnel_directory_url( $args = [] ) {
    $args = array_filter( $args, static function( $value ) {
        return '' !== $value && null !== $value && false !== $value;
    } );
    return add_query_arg( $args, get_permalink( 1381 ) );
}

function wmrn_personnel_related_accessions( $term_id ) {
    return get_posts( [
        'post_type'      => WMRN_Personnel_Authority::collection_post_type(),
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'tax_query'      => [
            [
                'taxonomy' => WMRN_Personnel_Authority::taxonomy(),
                'field'    => 'term_id',
                'terms'    => (int) $term_id,
            ],
        ],
    ] );
}

function wmrn_personnel_render_related_accessions( $term_id ) {
    $posts = wmrn_personnel_related_accessions( $term_id );
    if ( ! $posts ) {
        echo '<p>No published accession is currently linked to this personnel authority record.</p>';
        return;
    }
    echo '<div class="wmrn-personnel-related-grid">';
    foreach ( $posts as $post ) {
        $number = get_post_meta( $post->ID, 2732, true );
        $thumb  = get_the_post_thumbnail( $post->ID, 'medium', [ 'class' => 'wmrn-personnel-related-image', 'alt' => '' ] );
        echo '<a class="wmrn-personnel-related-card" href="' . esc_url( get_permalink( $post ) ) . '">';
        if ( $thumb ) {
            echo $thumb;
        }
        echo '<span class="wmrn-personnel-related-copy">';
        if ( $number ) {
            echo '<span class="wmrn-personnel-related-number">' . esc_html( $number ) . '</span>';
        }
        echo '<strong>' . esc_html( get_the_title( $post ) ) . '</strong>';
        echo '</span></a>';
    }
    echo '</div>';
}

function wmrn_personnel_assignment_date_label( $row ) {
    $start = trim( (string) ( $row['start'] ?? '' ) );
    $end   = trim( (string) ( $row['end'] ?? '' ) );
    if ( $start && $end ) {
        return $start === $end ? $start : $start . ' – ' . $end;
    }
    if ( $start ) {
        return 'From ' . $start;
    }
    if ( $end ) {
        return 'Through ' . $end;
    }
    return 'Date not yet documented';
}
