<?php
defined( 'ABSPATH' ) || exit;

/** The existing people term is the identity. This class never edits terms or relationships. */
final class WMRN_Personnel_Authority {
    const META = '_wmrn_personnel_authority';
    const HISTORY = '_wmrn_personnel_history';
    const DEFAULT_TAXONOMY = 'tnc_tax_2788';
    const COLLECTION_ID = 2719;
    const PEOPLE_METADATA_ID = 2837;

    public static function taxonomy() {
        return (string) apply_filters( 'wmrn_personnel_people_taxonomy', self::DEFAULT_TAXONOMY );
    }
    public static function collection_id() {
        return (int) apply_filters( 'wmrn_personnel_collection_id', self::COLLECTION_ID );
    }
    public static function collection_post_type() {
        return 'tnc_col_' . self::collection_id() . '_item';
    }

    public static function stations() {
        return apply_filters( 'wmrn_personnel_stations', [
            'wmrn-am-1490' => 'WMRN-AM 1490', 'wmrn-fm-1069' => 'WMRN-FM 106.9',
            'wdif-943' => 'WDIF 94.3', 'majic-959' => 'Majic 95.9',
        ] );
    }
    public static function roles() {
        return apply_filters( 'wmrn_personnel_roles', [
            'owner' => 'Owner', 'general-manager' => 'General Manager', 'station-manager' => 'Station Manager',
            'program-director' => 'Program Director', 'music-director' => 'Music Director',
            'news-director' => 'News Director', 'production-director' => 'Production Director',
            'announcer-air-personality' => 'Announcer / Air Personality', 'news-reporter' => 'News / Reporter',
            'sports' => 'Sports', 'engineer' => 'Engineering', 'sales' => 'Sales', 'traffic' => 'Traffic',
            'promotions' => 'Promotions', 'office-administration' => 'Office / Administration', 'other' => 'Other',
        ] );
    }
    public static function relationships() {
        return [ 'direct-wmrn' => 'Direct WMRN staff', 'shared-cluster' => 'Shared/cluster-wide staff',
            'sister-station' => 'Sister-station staff', 'ownership-management' => 'Ownership/management',
            'research-needed' => 'Research needed' ];
    }
    public static function verification() {
        return [ 'confirmed' => 'Confirmed', 'probable' => 'Probable / partially documented', 'research-needed' => 'Research needed' ];
    }
    public static function defaults() {
        return [ 'schema_version' => 1, 'is_personnel' => false, 'display_name' => '', 'sort_name' => '',
            'on_air_name' => '', 'portrait_id' => 0, 'start_year' => '', 'end_year' => '', 'employer' => '',
            'relationship' => '', 'stations' => [], 'roles' => [], 'primary_role' => '', 'department' => '',
            'biography' => '', 'timeline' => '', 'sources' => '', 'verification' => 'research-needed',
            'internal_notes' => '', 'featured' => false, 'assignments' => [] ];
    }
    public static function assignment_defaults() {
        return [ 'station' => '', 'role' => '', 'role_label' => '', 'department' => '',
            'start' => '', 'end' => '', 'date_type' => 'tenure', 'employer' => '', 'relationship' => '',
            'workplace' => '', 'notes' => '', 'verification' => 'research-needed', 'source' => '' ];
    }
    public static function register() {
        $taxonomy = self::taxonomy();
        if ( ! taxonomy_exists( $taxonomy ) ) { return; }
        register_term_meta( $taxonomy, self::META, [ 'type' => 'object', 'single' => true,
            'show_in_rest' => false, 'auth_callback' => function( $allowed, $meta_key, $term_id ) {
                return current_user_can( 'edit_term', $term_id );
            } ] );
        register_term_meta( $taxonomy, self::HISTORY, [ 'type' => 'array', 'single' => true,
            'show_in_rest' => false, 'auth_callback' => function( $allowed, $meta_key, $term_id ) {
                return current_user_can( 'edit_term', $term_id );
            } ] );
    }
    public static function raw( $id ) {
        $data = get_term_meta( (int) $id, self::META, true );
        return is_array( $data ) ? $data : [];
    }
    public static function get( $id ) {
        return array_replace( self::defaults(), self::raw( $id ) );
    }
    public static function version( $raw ) { return hash( 'sha256', wp_json_encode( $raw ) ); }
    public static function is_personnel( $id ) { return true === self::get( $id )['is_personnel']; }

    /** Explicit allowlist: private research and future unknown keys can never enter public output. */
    public static function public_data( $id ) {
        $data = self::get( $id );
        $keys = array_diff( array_keys( self::defaults() ), [ 'internal_notes', 'schema_version' ] );
        $public = array_intersect_key( $data, array_flip( $keys ) );
        $public['assignments'] = array_map( function( $row ) {
            return array_intersect_key( (array) $row, self::assignment_defaults() );
        }, (array) $public['assignments'] );
        return $public;
    }
    private static function fail( $message ) { return new WP_Error( 'wmrn_personnel_invalid', $message, [ 'status' => 400 ] ); }
    public static function valid_date( $value ) {
        if ( '' === $value ) { return true; }
        if ( ! preg_match( '/^(18|19|20|21)\d{2}(?:-(0[1-9]|1[0-2])(?:-(0[1-9]|[12]\d|3[01]))?)?$/D', $value ) ) { return false; }
        $parts = explode( '-', $value );
        return count( $parts ) < 3 || checkdate( (int) $parts[1], (int) $parts[2], (int) $parts[0] );
    }
    public static function date_bound( $date, $upper = false ) {
        if ( strlen( $date ) === 4 ) { return $date . ( $upper ? '-12-31' : '-01-01' ); }
        if ( strlen( $date ) === 7 ) { return $date . ( $upper ? '-' . date( 't', strtotime( $date . '-01' ) ) : '-01' ); }
        return $date;
    }
    public static function validate( $input ) {
        if ( ! is_array( $input ) ) { return self::fail( 'The authority record must be an object.' ); }
        $unknown = array_diff( array_keys( $input ), array_keys( self::defaults() ) );
        if ( $unknown ) { return self::fail( 'Unrecognized authority field: ' . implode( ', ', $unknown ) ); }
        $out = self::defaults();
        foreach ( $out as $key => $default ) {
            if ( ! array_key_exists( $key, $input ) ) { continue; }
            $value = $input[$key];
            if ( in_array( $key, [ 'stations', 'roles', 'assignments' ], true ) ) { continue; }
            if ( is_array( $value ) || is_object( $value ) || null === $value ) { return self::fail( 'Invalid value for ' . $key . '.' ); }
            if ( in_array( $key, [ 'is_personnel', 'featured' ], true ) ) {
                if ( ! in_array( $value, [ true, false, 1, 0, '1', '0', '' ], true ) ) { return self::fail( 'Invalid checkbox value.' ); }
                $out[$key] = in_array( $value, [ true, 1, '1' ], true );
            } elseif ( 'portrait_id' === $key ) {
                if ( '' !== $value && ! preg_match( '/^\d+$/D', (string) $value ) ) { return self::fail( 'Portrait must be a media-library image ID.' ); }
                $out[$key] = (int) $value;
                if ( $out[$key] && ! wp_attachment_is_image( $out[$key] ) ) { return self::fail( 'Select an image from the media library.' ); }
            } elseif ( 'schema_version' === $key ) {
                if ( 1 !== (int) $value ) { return self::fail( 'Unsupported authority schema version.' ); }
            } elseif ( in_array( $key, [ 'biography', 'timeline' ], true ) ) {
                $out[$key] = wp_kses_post( (string) $value );
            } else {
                $out[$key] = in_array( $key, [ 'sources', 'internal_notes' ], true ) ? sanitize_textarea_field( $value ) : sanitize_text_field( $value );
            }
            if ( is_string( $out[$key] ) && strlen( $out[$key] ) > 50000 ) { return self::fail( 'Field exceeds 50,000 bytes: ' . $key ); }
        }
        foreach ( [ 'start_year', 'end_year' ] as $key ) {
            if ( '' !== $out[$key] && ! preg_match( '/^(18|19|20|21)\d{2}$/D', $out[$key] ) ) { return self::fail( 'Years must be blank or a four-digit year (1800–2199).' ); }
        }
        if ( $out['start_year'] && $out['end_year'] && $out['start_year'] > $out['end_year'] ) { return self::fail( 'End year cannot precede start year.' ); }
        foreach ( [ 'stations' => self::stations(), 'roles' => self::roles() ] as $key => $choices ) {
            $values = $input[$key] ?? [];
            if ( ! is_array( $values ) || count( $values ) > 100 ) { return self::fail( 'Invalid list: ' . $key ); }
            foreach ( $values as $value ) {
                if ( ! is_string( $value ) || ! isset( $choices[$value] ) ) { return self::fail( 'Unknown selection in ' . $key ); }
            }
            $out[$key] = array_values( array_unique( $values ) );
        }
        foreach ( [ 'relationship' => self::relationships(), 'verification' => self::verification() ] as $key => $choices ) {
            if ( '' !== $out[$key] && ! isset( $choices[$out[$key]] ) ) { return self::fail( 'Unknown ' . $key . '.' ); }
        }
        $rows = $input['assignments'] ?? [];
        if ( ! is_array( $rows ) || count( $rows ) > 100 ) { return self::fail( 'Use no more than 100 career assignments per record.' ); }
        foreach ( $rows as $i => $row ) {
            if ( ! is_array( $row ) || array_diff( array_keys( $row ), array_keys( self::assignment_defaults() ) ) ) { return self::fail( 'Invalid career assignment structure.' ); }
            $clean = self::assignment_defaults();
            foreach ( $row as $key => $value ) {
                if ( ! is_scalar( $value ) || strlen( (string) $value ) > 10000 ) { return self::fail( 'Invalid career assignment value.' ); }
                $clean[$key] = in_array( $key, [ 'notes', 'source' ], true ) ? sanitize_textarea_field( $value ) : sanitize_text_field( $value );
            }
            $meaningful = array_diff_key( $clean, array_flip( [ 'verification', 'date_type' ] ) );
            if ( ! array_filter( $meaningful, 'strlen' ) ) { continue; }
            foreach ( [ 'station' => self::stations(), 'role' => self::roles(), 'relationship' => self::relationships(), 'verification' => self::verification(), 'date_type' => [ 'tenure' => '', 'documented' => '' ] ] as $key => $choices ) {
                if ( '' !== $clean[$key] && ! array_key_exists( $clean[$key], $choices ) ) { return self::fail( 'Unknown ' . $key . ' in career assignment ' . ( $i + 1 ) ); }
            }
            if ( ! self::valid_date( $clean['start'] ) || ! self::valid_date( $clean['end'] ) ) { return self::fail( 'Assignment dates must be blank, YYYY, YYYY-MM or YYYY-MM-DD.' ); }
            if ( $clean['start'] && $clean['end'] && self::date_bound( $clean['start'] ) > self::date_bound( $clean['end'], true ) ) { return self::fail( 'An assignment end precedes its start.' ); }
            $out['assignments'][] = $clean;
        }
        return $out;
    }
    /** Same validation and capability checks for the taxonomy editor, REST and WP-CLI. */
    public static function save( $id, $input, $expected_version ) {
        $term = get_term( $id, self::taxonomy() );
        if ( ! $term || is_wp_error( $term ) ) { return new WP_Error( 'not_found', 'Existing People term required.', [ 'status' => 404 ] ); }
        if ( ! current_user_can( 'edit_term', $id ) ) { return new WP_Error( 'forbidden', 'You cannot edit this People term.', [ 'status' => 403 ] ); }
        $old = self::raw( $id );
        if ( ! is_string( $expected_version ) || ! hash_equals( self::version( $old ), $expected_version ) ) {
            return new WP_Error( 'conflict', 'This authority record changed. Reload it before saving to avoid overwriting another edit.', [ 'status' => 409 ] );
        }
        $next = self::validate( $input );
        if ( is_wp_error( $next ) ) { return $next; }
        if ( $next === $old ) { return $next; }
        if ( ! $old && $next === self::defaults() ) { return $next; }
        $saved = $old ? update_term_meta( $id, self::META, wp_slash( $next ), $old ) : add_term_meta( $id, self::META, wp_slash( $next ), true );
        if ( ! $saved || is_wp_error( $saved ) ) { return new WP_Error( 'save_failed', 'The record was not saved. Reload and retry.', [ 'status' => 409 ] ); }
        $history = get_term_meta( $id, self::HISTORY, true );
        $history = is_array( $history ) ? $history : [];
        $history[] = [ 'at' => gmdate( 'c' ), 'user_id' => get_current_user_id(), 'previous' => $old ];
        update_term_meta( $id, self::HISTORY, wp_slash( array_slice( $history, -10 ) ) );
        do_action( 'wmrn_personnel_updated', $id, $next );
        return $next;
    }
    public static function labels( $slugs, $choices ) {
        return array_map( function( $slug ) use ( $choices ) { return $choices[$slug] ?? $slug; }, $slugs );
    }
    public static function all_stations( $data ) {
        return array_values( array_unique( array_filter( array_merge( $data['stations'], array_column( $data['assignments'], 'station' ) ) ) ) );
    }
    public static function all_roles( $data ) {
        return array_values( array_unique( array_filter( array_merge( $data['roles'], array_column( $data['assignments'], 'role' ) ) ) ) );
    }
    /** Unknown boundaries only match their documented endpoint, never an inferred open interval. */
    public static function date_matches( $start, $end, $from, $to, $type = 'tenure' ) {
        $a = $start ? (int) substr( $start, 0, 4 ) : 0;
        $b = $end ? (int) substr( $end, 0, 4 ) : 0;
        if ( ! $a && ! $b ) { return false; }
        if ( 'documented' === $type ) { return ( $a >= $from && $a <= $to ) || ( $b >= $from && $b <= $to ); }
        if ( ! $a ) { $a = $b; }
        if ( ! $b ) { $b = $a; }
        return $a <= $to && $b >= $from;
    }
    public static function matches( $data, $filters ) {
        $active_filters = array_filter( $filters, 'strlen' );
        if ( $active_filters && empty( $data['is_personnel'] ) ) { return false; }
        if ( ! empty( $filters['verification'] ) && $data['verification'] !== $filters['verification'] ) { return false; }
        $career_keys = [ 'station', 'role', 'era', 'year', 'relationship', 'employer', 'department' ];
        $active = array_intersect_key( $active_filters, array_flip( $career_keys ) );
        if ( ! $active ) { return true; }
        $rows = $data['assignments'];
        if ( ! $rows ) {
            $rows = [ [ 'stations' => $data['stations'], 'roles' => $data['roles'], 'start' => $data['start_year'],
                'end' => $data['end_year'], 'relationship' => $data['relationship'], 'employer' => $data['employer'],
                'department' => $data['department'], 'date_type' => 'tenure' ] ];
        }
        foreach ( $rows as $row ) {
            $ok = true;
            foreach ( [ 'station' => 'stations', 'role' => 'roles' ] as $key => $plural ) {
                if ( $filters[$key] && ! in_array( $filters[$key], $row[$plural] ?? [ $row[$key] ?? '' ], true ) ) { $ok = false; }
            }
            if ( $filters['relationship'] && $filters['relationship'] !== $row['relationship'] ) { $ok = false; }
            foreach ( [ 'employer', 'department' ] as $key ) {
                if ( $filters[$key] && false === stripos( $row[$key], $filters[$key] ) ) { $ok = false; }
            }
            if ( $filters['era'] && ! self::date_matches( $row['start'], $row['end'], (int) $filters['era'], (int) $filters['era'] + 9, $row['date_type'] ) ) { $ok = false; }
            if ( $filters['year'] && ! self::date_matches( $row['start'], $row['end'], (int) $filters['year'], (int) $filters['year'], $row['date_type'] ) ) { $ok = false; }
            if ( $ok ) { return true; }
        }
        return false;
    }
}
