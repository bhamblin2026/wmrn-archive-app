<?php
defined( 'ABSPATH' ) || exit;

final class WMRN_Personnel_Integration {
    const PROFILE_QUERY_VAR = 'wmrn_personnel_person';
    const DIRECTORY_PAGE_ID = 1381;
    const DIRECTORY_SLUG = 'personnel-directory';
    const LEGACY_DIRECTORY_SLUG = 'people-directory';

    public static function boot() {
        add_action( 'init', [ __CLASS__, 'rewrite' ], 60 );
        add_action( 'init', [ __CLASS__, 'maybe_migrate_directory_slug' ], 70 );
        add_filter( 'query_vars', [ __CLASS__, 'query_vars' ] );
        add_filter( 'home_url', [ __CLASS__, 'legacy_home_url' ], 20, 4 );
        add_filter( 'site_url', [ __CLASS__, 'legacy_site_url' ], 20, 4 );
        add_filter( 'request', [ __CLASS__, 'request_vars' ], 1 );
        add_action( 'template_redirect', [ __CLASS__, 'legacy_redirect' ], 0 );
        add_filter( 'template_include', [ __CLASS__, 'template' ], 99 );
        add_action( 'template_redirect', [ __CLASS__, 'profile_status' ], 1 );
        add_filter( 'redirect_canonical', [ __CLASS__, 'canonical' ], 10, 2 );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'assets' ], 30 );
        add_action( 'rest_api_init', [ __CLASS__, 'rest' ] );
        add_action( 'wmrn_personnel_updated', [ __CLASS__, 'purge' ] );
        add_action( 'admin_notices', [ __CLASS__, 'notices' ] );
        add_filter( 'pre_get_document_title', [ __CLASS__, 'document_title' ], 20 );
        add_filter( 'aioseo_title', [ __CLASS__, 'aioseo_title' ], 20 );
        add_filter( 'aioseo_description', [ __CLASS__, 'aioseo_description' ], 20 );

        if ( defined( 'WP_CLI' ) && WP_CLI ) {
            WP_CLI::add_command( 'wmrn personnel get', function( $args ) {
                $id = (int) ( $args[0] ?? 0 );
                if ( ! current_user_can( 'edit_term', $id ) ) {
                    WP_CLI::error( 'Use --user with an authorized People editor.' );
                }
                WP_CLI::line( wp_json_encode( [
                    'term_id' => $id,
                    'record'  => WMRN_Personnel_Authority::get( $id ),
                    'version' => WMRN_Personnel_Authority::version( WMRN_Personnel_Authority::raw( $id ) ),
                ], JSON_PRETTY_PRINT ) );
            } );

            WP_CLI::add_command( 'wmrn personnel update', function( $args, $assoc ) {
                $input = json_decode( file_get_contents( $args[1] ?? '' ), true );
                $result = WMRN_Personnel_Authority::save(
                    (int) ( $args[0] ?? 0 ),
                    $input,
                    $assoc['version'] ?? ''
                );
                if ( is_wp_error( $result ) ) {
                    WP_CLI::error( $result->get_error_message() );
                }
                WP_CLI::success( 'Personnel authority saved; Tainacan People identity and archive relationships retained.' );
            } );
        }
    }

    public static function rewrite() {
        add_rewrite_rule(
            '^' . preg_quote( self::DIRECTORY_SLUG, '#' ) . '/([^/]+)/?$',
            'index.php?' . self::PROFILE_QUERY_VAR . '=$matches[1]',
            'top'
        );
    }

    public static function activate() {
        self::rewrite();
        flush_rewrite_rules( false );
    }

    public static function deactivate() {
        flush_rewrite_rules( false );
    }

    public static function query_vars( $vars ) {
        $vars[] = self::PROFILE_QUERY_VAR;
        return $vars;
    }

    public static function maybe_migrate_directory_slug() {
        $migration_key = 'wmrn_personnel_directory_slug_migration';
        if ( WMRN_PERSONNEL_VERSION === get_option( $migration_key ) ) {
            return;
        }

        $page = get_post( self::DIRECTORY_PAGE_ID );
        if ( $page && 'page' === $page->post_type && self::DIRECTORY_SLUG !== $page->post_name ) {
            $updated = wp_update_post( [
                'ID'        => self::DIRECTORY_PAGE_ID,
                'post_name' => self::DIRECTORY_SLUG,
            ], true );
            if ( is_wp_error( $updated ) ) {
                return;
            }
        }

        flush_rewrite_rules( false );
        update_option( $migration_key, WMRN_PERSONNEL_VERSION, false );
    }

    private static function canonical_directory_url() {
        return untrailingslashit( (string) get_option( 'home' ) ) . '/' . self::DIRECTORY_SLUG . '/';
    }

    private static function is_legacy_directory_path( $path ) {
        $path = '/' . trim( (string) $path, '/' ) . '/';
        return in_array( $path, [ '/people/', '/' . self::LEGACY_DIRECTORY_SLUG . '/' ], true );
    }

    public static function legacy_home_url( $url, $path, $orig_scheme, $blog_id ) {
        return self::is_legacy_directory_path( $path ) ? self::canonical_directory_url() : $url;
    }

    public static function legacy_site_url( $url, $path, $scheme, $blog_id ) {
        return self::is_legacy_directory_path( $path ) ? self::canonical_directory_url() : $url;
    }

    public static function request_vars( $query_vars ) {
        $uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
        if ( false !== strpos( $uri, '/' . self::DIRECTORY_SLUG . '/' ) && isset( $_GET['year'] ) ) {
            unset( $query_vars['year'] );
        }
        return $query_vars;
    }

    public static function legacy_redirect() {
        if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
            return;
        }

        $uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
        $path = (string) wp_parse_url( $uri, PHP_URL_PATH );

        if ( preg_match( '#^/' . preg_quote( self::LEGACY_DIRECTORY_SLUG, '#' ) . '(?:/([^/]+))?/?$#', $path, $matches ) ) {
            $target = home_url( '/' . self::DIRECTORY_SLUG . '/' );
            if ( ! empty( $matches[1] ) ) {
                $target = home_url( '/' . self::DIRECTORY_SLUG . '/' . rawurlencode( sanitize_title( $matches[1] ) ) . '/' );
            }

            $query = wp_parse_url( $uri, PHP_URL_QUERY );
            if ( $query ) {
                $target .= '?' . $query;
            }

            wp_safe_redirect( $target, 301 );
            exit;
        }

        if ( '/people/' === trailingslashit( $path ) ) {
            wp_safe_redirect( home_url( '/' . self::DIRECTORY_SLUG . '/' ), 301 );
            exit;
        }
    }

    public static function is_directory() {
        return is_page( self::DIRECTORY_PAGE_ID );
    }

    public static function profile_slug() {
        return sanitize_title( (string) get_query_var( self::PROFILE_QUERY_VAR ) );
    }

    public static function profile_term() {
        $slug = self::profile_slug();
        if ( ! $slug ) {
            return null;
        }
        $term = get_term_by( 'slug', $slug, WMRN_Personnel_Authority::taxonomy() );
        if ( ! $term || is_wp_error( $term ) || ! WMRN_Personnel_Authority::is_personnel( $term->term_id ) ) {
            return null;
        }
        return $term;
    }

    public static function is_profile() {
        return (bool) self::profile_term();
    }

    public static function profile_status() {
        if ( ! self::profile_slug() ) {
            return;
        }
        $term = self::profile_term();
        if ( ! $term ) {
            return;
        }
        global $wp_query;
        if ( $wp_query ) {
            $wp_query->is_404 = false;
        }
        status_header( 200 );
    }

    public static function canonical( $redirect_url, $requested_url ) {
        if ( self::profile_slug() ) {
            return false;
        }
        return $redirect_url;
    }

    public static function template( $template ) {
        if ( self::is_directory() ) {
            $name = 'page-people-directory.php';
        } elseif ( self::profile_slug() ) {
            $term = self::profile_term();
            if ( ! $term ) {
                global $wp_query;
                $wp_query->set_404();
                status_header( 404 );
                nocache_headers();
                return get_404_template() ?: $template;
            }
            $name = 'taxonomy-people-personnel.php';
        } else {
            return $template;
        }

        $theme = locate_template( 'wmrn-personnel/' . $name );
        return $theme ?: WMRN_PERSONNEL_DIR . 'templates/' . $name;
    }

    public static function assets() {
        if ( self::is_directory() || self::profile_slug() ) {
            wp_enqueue_style(
                'wmrn-personnel',
                WMRN_PERSONNEL_URL . 'assets/personnel.css',
                [],
                WMRN_PERSONNEL_VERSION
            );
        }
    }

    public static function seo_context() {
        if ( self::is_directory() ) {
            return [
                'title'       => 'WMRN Personnel Directory',
                'description' => 'Explore the historical personnel of WMRN-AM 1490, WMRN-FM 106.9, WDIF 94.3, Majic 95.9, and the shared Marion radio operation documented by the WMRN Radio History Archive.',
            ];
        }

        $term = self::profile_term();
        if ( ! $term ) {
            return null;
        }

        $data  = WMRN_Personnel_Authority::public_data( $term->term_id );
        $name  = wmrn_personnel_display_name( $term, $data );
        $role  = trim( (string) ( $data['primary_role'] ?? '' ) );
        $years = wmrn_personnel_years( $data );

        $detail = array_filter( [ $role, $years ] );
        $description = $name . ' — historical WMRN personnel profile in the WMRN Radio History Archive.';
        if ( $detail ) {
            $description = $name . ': ' . implode( ', ', $detail ) . '. Historical personnel profile in the WMRN Radio History Archive.';
        }

        return [
            'title'       => $name . ' — WMRN Personnel Profile',
            'description' => $description,
        ];
    }

    public static function document_title( $title ) {
        $context = self::seo_context();
        return $context ? $context['title'] : $title;
    }

    public static function aioseo_title( $title ) {
        $context = self::seo_context();
        return $context ? $context['title'] : $title;
    }

    public static function aioseo_description( $description ) {
        $context = self::seo_context();
        return $context ? $context['description'] : $description;
    }

    public static function notices() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $taxonomy = WMRN_Personnel_Authority::taxonomy();
        if ( ! taxonomy_exists( $taxonomy ) ) {
            echo '<div class="notice notice-error"><p>WMRN Personnel Authority requires the current Tainacan People taxonomy (' . esc_html( $taxonomy ) . '). No replacement taxonomy has been created.</p></div>';
        }

        if ( 'publish' === get_post_status( 3644 ) || 'publish' === get_post_status( 3645 ) ) {
            echo '<div class="notice notice-error"><p>Personnel prototype snippets 3644 and 3645 must remain disabled when WMRN Personnel Authority is active. Review WPCode to prevent conflicting fields or templates.</p></div>';
        }
    }

    public static function rest_permission( $request ) {
        $id = (int) $request['id'];
        $term = get_term( $id, WMRN_Personnel_Authority::taxonomy() );
        return $term && ! is_wp_error( $term ) && current_user_can( 'edit_term', $id );
    }

    public static function rest() {
        register_rest_route( 'wmrn-personnel/v1', '/people/(?P<id>\d+)', [
            [
                'methods'             => 'GET',
                'permission_callback' => [ __CLASS__, 'rest_permission' ],
                'callback'            => function( $request ) {
                    $response = new WP_REST_Response( [
                        'term_id' => (int) $request['id'],
                        'record'  => WMRN_Personnel_Authority::get( $request['id'] ),
                        'version' => WMRN_Personnel_Authority::version( WMRN_Personnel_Authority::raw( $request['id'] ) ),
                    ] );
                    $response->header( 'Cache-Control', 'private, no-store' );
                    return $response;
                },
            ],
            [
                'methods'             => 'PUT',
                'permission_callback' => [ __CLASS__, 'rest_permission' ],
                'callback'            => function( $request ) {
                    $body = $request->get_json_params();
                    if ( ! is_array( $body ) || ! isset( $body['record'], $body['version'] ) ) {
                        return new WP_Error( 'invalid_request', 'record and version are required.', [ 'status' => 400 ] );
                    }
                    $result = WMRN_Personnel_Authority::save(
                        (int) $request['id'],
                        $body['record'],
                        $body['version']
                    );
                    if ( is_wp_error( $result ) ) {
                        return $result;
                    }
                    $response = new WP_REST_Response( [
                        'term_id' => (int) $request['id'],
                        'saved'   => true,
                        'version' => WMRN_Personnel_Authority::version( WMRN_Personnel_Authority::raw( $request['id'] ) ),
                    ] );
                    $response->header( 'Cache-Control', 'private, no-store' );
                    return $response;
                },
            ],
        ] );
    }

    public static function purge( $id ) {
        clean_term_cache( $id, WMRN_Personnel_Authority::taxonomy() );

        if ( function_exists( 'rocket_clean_files' ) ) {
            $term = get_term( $id, WMRN_Personnel_Authority::taxonomy() );
            $urls = [ get_permalink( 1381 ) ];
            if ( $term && ! is_wp_error( $term ) ) {
                $urls[] = wmrn_personnel_profile_url( $term );
                $urls[] = wmrn_personnel_archive_person_url( $id );
            }
            rocket_clean_files( array_filter( $urls ) );
        }
    }
}
