(function () {
    'use strict';
    var list = document.getElementById('wmrn-pa-assignments');
    if (!list) return;
    var add = document.getElementById('wmrn-pa-add');
    var status = document.getElementById('wmrn-pa-status');
    var next = list.children.length;
    add.addEventListener('click', function () {
        var source = document.getElementById('wmrn-pa-assignment-template').innerHTML.replace(/__INDEX__/g, String(next++));
        var holder = document.createElement('div');
        holder.innerHTML = source;
        var row = holder.firstElementChild;
        row.querySelector('.wmrn-pa-number').textContent = String(next);
        list.appendChild(row);
        row.querySelector('select').focus();
        status.textContent = 'Career assignment added.';
    });
    list.addEventListener('click', function (event) {
        if (!event.target.classList.contains('wmrn-pa-remove')) return;
        event.target.closest('.wmrn-pa-assignment').remove();
        add.focus();
        status.textContent = 'Assignment removed from this form. Update the person to save the change.';
    });
    document.getElementById('wmrn-pa-portrait-select').addEventListener('click', function () {
        var frame = wp.media({title: 'Select a documented personnel portrait', library: {type: 'image'}, multiple: false});
        frame.on('select', function () {
            var item = frame.state().get('selection').first().toJSON();
            document.getElementById('wmrn-pa-portrait_id').value = item.id;
            var img = document.createElement('img');
            img.src = item.sizes && item.sizes.thumbnail ? item.sizes.thumbnail.url : item.url;
            img.alt = item.alt || '';
            document.getElementById('wmrn-pa-portrait-preview').replaceChildren(img);
        });
        frame.open();
    });
    document.getElementById('wmrn-pa-portrait-clear').addEventListener('click', function () {
        document.getElementById('wmrn-pa-portrait_id').value = 0;
        document.getElementById('wmrn-pa-portrait-preview').replaceChildren();
    });
}());
